import { Injectable, Logger } from '@nestjs/common';
import ffmpeg from 'fluent-ffmpeg';
import ffmpegStatic from 'ffmpeg-static';
import { join } from 'path';
import { tmpdir } from 'os';
import { existsSync, mkdirSync } from 'fs';

if (ffmpegStatic) {
  ffmpeg.setFfmpegPath(ffmpegStatic as string);
}

@Injectable()
export class AudioService {
  private readonly logger = new Logger(AudioService.name);

  async sliceAudio(
    inputPath: string,
    startTime: number,
    endTime: number,
  ): Promise<string> {
    const duration = Math.max(0.01, endTime - startTime);
    const tempDir = join(tmpdir(), 'guitarmate-audio');
    if (!existsSync(tempDir)) {
      mkdirSync(tempDir, { recursive: true });
    }

    const outputPath = join(
      tempDir,
      `slice_${Date.now()}_${Math.random().toString(36).slice(2)}.mp3`,
    );

    this.logger.log(
      `Slicing audio from ${startTime.toFixed(3)}s to ${endTime.toFixed(3)}s (duration ${duration.toFixed(3)}s) for ${inputPath}`,
    );

    // 计算淡出起始时间，淡入 5ms (0.005s), 淡出 5ms
    const fadeOutStart = Math.max(0.001, duration - 0.005);
    const audioFilter = `afade=t=in:d=0.005,afade=t=out:st=${fadeOutStart.toFixed(3)}:d=0.005`;

    return new Promise<string>((resolve, reject) => {
      ffmpeg(inputPath)
        .setStartTime(startTime)
        .setDuration(duration)
        .audioCodec('libmp3lame')
        .audioBitrate('192k')
        .outputOptions(['-af', audioFilter])
        .on('start', (cmdline) => {
          this.logger.debug(`FFmpeg command: ${cmdline}`);
        })
        .on('end', () => {
          this.logger.log(`Audio slice created successfully at: ${outputPath}`);
          resolve(outputPath);
        })
        .on('error', (err) => {
          this.logger.error(`FFmpeg slice error: ${err.message}`);
          reject(err);
        })
        .save(outputPath);
    });
  }
}
