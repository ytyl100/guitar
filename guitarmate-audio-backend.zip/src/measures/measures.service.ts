import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

export interface CreateMeasureData {
  scoreId: string;
  trackId: string;
  index: number;
  label: string;
  startTime: number;
  endTime: number;
  duration: number;
  bpm: number;
  timeSignature: string;
  audioUrl: string;
  tabImageUrl: string;
  imageWidth?: number;
  imageHeight?: number;
  notes: string; // 已序列化的 JSON 字符串
  barres?: Array<{
    instrument?: string;
    fret: number;
    fromString: number;
    toString: number;
    startTime: number;
    duration: number;
    x: number;
    y: number;
  }>;
  chords?: Array<{
    instrument?: string;
    chordName: string;
    startTime: number;
    duration: number;
    x: number;
    y: number;
  }>;
}

@Injectable()
export class MeasuresService {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateMeasureData) {
    return this.prisma.measure.create({
      data: {
        scoreId: data.scoreId,
        index: data.index,
        label: data.label,
        startTime: data.startTime,
        endTime: data.endTime,
        duration: data.duration,
        bpm: data.bpm,
        timeSignature: data.timeSignature,
        trackData: {
          create: {
            trackId: data.trackId,
            audioUrl: data.audioUrl,
            tabImageUrl: data.tabImageUrl,
            imageWidth: data.imageWidth ?? 1200,
            imageHeight: data.imageHeight ?? 300,
            notes: data.notes, // SQLite: 存序列化的 String
          },
        },
        barres: data.barres && data.barres.length > 0
          ? {
              create: data.barres.map((b) => ({
                instrument: b.instrument || 'guitar',
                fret: b.fret,
                fromString: b.fromString,
                toString: b.toString,
                startTime: b.startTime,
                duration: b.duration,
                x: b.x,
                y: b.y,
              })),
            }
          : undefined,
        chords: data.chords && data.chords.length > 0
          ? {
              create: data.chords.map((c) => ({
                instrument: c.instrument || 'guitar',
                chordName: c.chordName,
                startTime: c.startTime,
                duration: c.duration,
                x: c.x,
                y: c.y,
              })),
            }
          : undefined,
      },
      include: {
        trackData: true,
        barres: true,
        chords: true,
      },
    });
  }

  async findByScore(scoreId: string) {
    const score = await this.prisma.score.findUnique({
      where: { id: scoreId },
    });

    if (!score) {
      throw new NotFoundException(`Score with ID '${scoreId}' not found`);
    }

    const measures = await this.prisma.measure.findMany({
      where: { scoreId },
      orderBy: { index: 'asc' },
      include: {
        trackData: true,
        barres: true,
        chords: true,
      },
    });

    // 反序列化 notes: String -> Note[]
    return measures.map((m) => ({
      ...m,
      trackData: m.trackData.map((t) => {
        let parsedNotes: any[] = [];
        try {
          parsedNotes = t.notes ? JSON.parse(t.notes) : [];
        } catch {
          parsedNotes = [];
        }
        return {
          ...t,
          notes: parsedNotes,
        };
      }),
    }));
  }
}
