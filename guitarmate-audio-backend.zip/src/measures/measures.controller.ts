import {
  Body,
  Controller,
  HttpCode,
  HttpStatus,
  Logger,
  Post,
  Req,
  BadRequestException,
} from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { MeasuresService } from './measures.service';
import { AudioService } from '../audio/audio.service';
import { OssService } from '../oss/oss.service';
import { PublishMeasuresDto } from './dto/publish-measures.dto';

@ApiTags('Measures')
@Controller('api/measures')
export class MeasuresController {
  private readonly logger = new Logger(MeasuresController.name);

  constructor(
    private readonly measures: MeasuresService,
    private readonly audio: AudioService,
    private readonly oss: OssService,
  ) {}

  @Post('publish')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: '发布曲目小节数据 (音频切片 + OSS 上传 + 计算相对时间 + 写入 SQLite)',
    description:
      '接收乐谱小节列表与原始分轨音频，依次切片对应区间音频、上传至 OSS CDN，将音符绝对时间转换为相对当前小节起始时间的 relativeTime，最后以 JSON 序列化形式存入 SQLite 数据库。',
  })
  @ApiResponse({ status: 200, description: '小节数据发布与入库成功' })
  @ApiResponse({ status: 400, description: '请求体参数校验失败' })
  async publish(@Body() dto: PublishMeasuresDto, @Req() req: any) {
    if (!dto.measures || dto.measures.length === 0) {
      throw new BadRequestException('measures array cannot be empty');
    }

    try {
      const results = [];
      const rawMeasures = req?.body?.measures || [];

      for (let mIndex = 0; mIndex < dto.measures.length; mIndex++) {
        const m = dto.measures[mIndex];
        const rawM = rawMeasures[mIndex] || {};
        let audioUrl = '';

        // 1. 切音频 & 2. 上传 OSS
        try {
          const localPath = await this.audio.sliceAudio(
            dto.trackAudioPath,
            m.startTime,
            m.endTime,
          );
          audioUrl = await this.oss.upload(localPath, `measures/${dto.scoreId}`);
        } catch (err: any) {
          this.logger.warn(
            `Audio slicing/uploading failed for measure ${m.index}: ${err.message}. Using fallback audio reference.`,
          );
          audioUrl = `${dto.trackAudioPath}#t=${m.startTime},${m.endTime}`;
        }

        // 3. 计算音符相对时间 (relativeTime = audioTime - startTime)
        const notes = (m.notes || []).map((n, noteIndex) => ({
          id: n.id || `n_${m.index}_${noteIndex}`,
          string: n.string,
          fret: n.fret,
          pitch: n.pitch,
          relativeTime: Number((n.audioTime - m.startTime).toFixed(4)),
          duration: n.duration,
          confidence: n.confidence ?? 1.0,
          x: n.x ?? 0,
          y: n.y ?? 0,
        }));

        // 提取横按数据并安全处理 toString (避免 JavaScript Object.prototype.toString 函数冲突)
        const rawBarres = rawM.barres || m.barres || [];
        const sanitizedBarres = (rawBarres || []).map((b: any) => {
          let toStringVal = 6;
          if (typeof b.toString === 'number') {
            toStringVal = b.toString;
          } else if (typeof b.endString === 'number') {
            toStringVal = b.endString;
          } else if (typeof b.fromString === 'number') {
            toStringVal = b.fromString;
          }
          return {
            instrument: b.instrument || 'guitar',
            fret: b.fret,
            fromString: b.fromString,
            toString: toStringVal,
            startTime: b.startTime,
            duration: b.duration,
            x: b.x,
            y: b.y,
          };
        });

        // 4. 写库 (SQLite: notes 存储为 JSON 序列化后的 String)
        const measure = await this.measures.create({
          scoreId: dto.scoreId,
          trackId: dto.trackId,
          startTime: m.startTime,
          endTime: m.endTime,
          duration: Number((m.endTime - m.startTime).toFixed(4)),
          bpm: dto.bpm,
          timeSignature: dto.timeSignature,
          label: m.label,
          index: m.index,
          audioUrl,
          tabImageUrl: m.tabImageUrl,
          imageWidth: 1200,
          imageHeight: 300,
          notes: JSON.stringify(notes), // ← SQLite: String
          barres: sanitizedBarres,
          chords: m.chords,
        });

        results.push(measure);
      }

      return {
        success: true,
        message: `Successfully published ${results.length} measures`,
        scoreId: dto.scoreId,
        trackId: dto.trackId,
        measures: results,
      };
    } catch (err: any) {
      this.logger.error(`Publish error: ${err.message}`, err.stack);
      throw new BadRequestException(`Publish error: ${err.message}`);
    }
  }
}
