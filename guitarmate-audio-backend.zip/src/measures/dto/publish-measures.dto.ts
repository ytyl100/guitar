import { Type } from 'class-transformer';
import {
  IsArray,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class NoteInputDto {
  @ApiPropertyOptional({ description: '音符唯一标识', example: 'n_1_0' })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ description: '绝对音频时间（秒）', example: 1.25 })
  @IsNumber()
  @IsNotEmpty()
  audioTime!: number;

  @ApiProperty({ description: '琴弦编号 (1-6，1为最细弦)', example: 1 })
  @IsInt()
  string!: number;

  @ApiProperty({ description: '品位 (0-24)', example: 3 })
  @IsInt()
  fret!: number;

  @ApiProperty({ description: 'MIDI 音高', example: 67 })
  @IsInt()
  pitch!: number;

  @ApiProperty({ description: '持续时间（秒）', example: 0.5 })
  @IsNumber()
  duration!: number;

  @ApiPropertyOptional({ description: '识别置信度 (0-1)', example: 0.98 })
  @IsOptional()
  @IsNumber()
  confidence?: number;

  @ApiPropertyOptional({ description: '归一化横坐标 (0-1)', example: 0.25 })
  @IsOptional()
  @IsNumber()
  x?: number;

  @ApiPropertyOptional({ description: '归一化纵坐标 (0-1)', example: 0.15 })
  @IsOptional()
  @IsNumber()
  y?: number;
}

export interface BarreInputDto {
  instrument?: string;
  fret: number;
  fromString: number;
  toString: number;
  startTime: number;
  duration: number;
  x: number;
  y: number;
}

export class ChordMarkerInputDto {
  @ApiPropertyOptional({ description: '所属乐器', example: 'guitar' })
  @IsOptional()
  @IsString()
  instrument?: string;

  @ApiProperty({ description: '和弦名称', example: 'Bm' })
  @IsString()
  @IsNotEmpty()
  chordName!: string;

  @ApiProperty({ description: '和弦起始时间（秒）', example: 0.0 })
  @IsNumber()
  startTime!: number;

  @ApiProperty({ description: '持续时间（秒）', example: 2.0 })
  @IsNumber()
  duration!: number;

  @ApiProperty({ description: '归一化横坐标 X', example: 0.15 })
  @IsNumber()
  x!: number;

  @ApiProperty({ description: '归一化纵坐标 Y', example: 0.05 })
  @IsNumber()
  y!: number;
}

export class MeasureItemDto {
  @ApiProperty({ description: '小节序号 (1-indexed)', example: 1 })
  @IsInt()
  index!: number;

  @ApiProperty({ description: '小节标签', example: '前奏 第1小节' })
  @IsString()
  @IsNotEmpty()
  label!: string;

  @ApiProperty({ description: '小节在全曲的起始时间（秒）', example: 0.0 })
  @IsNumber()
  startTime!: number;

  @ApiProperty({ description: '小节在全曲的结束时间（秒）', example: 3.2 })
  @IsNumber()
  endTime!: number;

  @ApiProperty({
    description: '当前小节的音符列表',
    type: [NoteInputDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => NoteInputDto)
  notes!: NoteInputDto[];

  @ApiPropertyOptional({
    description: '横按标记列表',
    type: 'array',
    items: {
      type: 'object',
      properties: {
        instrument: { type: 'string', example: 'guitar' },
        fret: { type: 'number', example: 1 },
        fromString: { type: 'number', example: 1 },
        toString: { type: 'number', example: 6 },
        startTime: { type: 'number', example: 0.0 },
        duration: { type: 'number', example: 2.0 },
        x: { type: 'number', example: 0.1 },
        y: { type: 'number', example: 0.2 },
      },
    },
  })
  @IsOptional()
  @IsArray()
  barres?: BarreInputDto[];

  @ApiPropertyOptional({
    description: '和弦标记列表',
    type: [ChordMarkerInputDto],
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ChordMarkerInputDto)
  chords?: ChordMarkerInputDto[];

  @ApiProperty({
    description: '六线谱切片图片 URL',
    example: 'https://cdn.example.com/tabs/measure_1.png',
  })
  @IsString()
  tabImageUrl!: string;
}

export class PublishMeasuresDto {
  @ApiProperty({ description: '所属曲目 ID', example: 'cmu8g2bpf0000i5aqfe8asyf3' })
  @IsString()
  @IsNotEmpty()
  scoreId!: string;

  @ApiProperty({ description: '所属分轨 ID', example: 'cmu8g2bpg0001i5aqq2s0a1b2' })
  @IsString()
  @IsNotEmpty()
  trackId!: string;

  @ApiProperty({
    description: '分轨原始音频路径或URL',
    example: 'https://cdn.example.com/hotel_california_lead.mp3',
  })
  @IsString()
  @IsNotEmpty()
  trackAudioPath!: string;

  @ApiProperty({ description: '速度 BPM', example: 75 })
  @IsInt()
  bpm!: number;

  @ApiProperty({ description: '拍号', example: '4/4' })
  @IsString()
  timeSignature!: string;

  @ApiProperty({
    description: '发布的小节列表',
    type: [MeasureItemDto],
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => MeasureItemDto)
  measures!: MeasureItemDto[];
}
