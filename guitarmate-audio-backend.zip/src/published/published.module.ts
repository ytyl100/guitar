import { Module } from '@nestjs/common';
import { PublishedController } from './published.controller';
import { MeasuresModule } from '../measures/measures.module';

@Module({
  imports: [MeasuresModule],
  controllers: [PublishedController],
})
export class PublishedModule {}
