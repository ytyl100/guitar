import { Controller, Get, Param } from '@nestjs/common';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { PrismaService } from '../prisma/prisma.service';
import { MeasuresService } from '../measures/measures.service';

@ApiTags('Published')
@Controller('api/published')
export class PublishedController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly measures: MeasuresService,
  ) {}

  @Get('scores')
  @ApiOperation({
    summary: '获取已发布曲目列表 (面向小程序端)',
    description: '过滤 status="published" 的乐谱列表，附带小节总数和分轨总数。',
  })
  @ApiResponse({ status: 200, description: '成功返回已发布曲目列表' })
  async listScores() {
    const scores = await this.prisma.score.findMany({
      where: { status: 'published' },
      select: {
        id: true,
        title: true,
        artist: true,
        coverUrl: true,
        bpm: true,
        timeSignature: true,
        createdAt: true,
        _count: {
          select: {
            measures: true,
            tracks: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return scores;
  }

  @Get('scores/:id/measures')
  @ApiOperation({
    summary: '获取指定曲目的所有小节与关联数据',
    description:
      '根据 scoreId 查询全部小节、分轨音频、指弹谱图、横按 Barre、和弦标记 ChordMarker，并将 SQLite 中的 notes 字符串反序列化为 Note[] 数组。',
  })
  @ApiParam({ name: 'id', description: '曲目 Score ID' })
  @ApiResponse({ status: 200, description: '成功返回小节列表及反序列化音符' })
  @ApiResponse({ status: 404, description: '曲目不存在' })
  async getMeasures(@Param('id') id: string) {
    return this.measures.findByScore(id);
  }
}
