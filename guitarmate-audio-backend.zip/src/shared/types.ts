// src/shared/types.ts
export interface Note {
  id: string;
  string: number;       // 1-6 (1=最细弦，6=最粗弦)
  fret: number;         // 0-24 品位
  pitch: number;        // MIDI 音高
  relativeTime: number; // 相对当前小节起始秒数 (audioTime - startTime)
  duration: number;     // 持续时间 (秒)
  confidence: number;   // 识别置信度 (0-1)
  x: number;            // 归一化横坐标 (0-1)
  y: number;            // 归一化纵坐标 (0-1)
}

export interface Barre {
  id?: string;
  instrument?: string;
  fret: number;
  fromString: number;
  toString: number;
  startTime: number;
  duration: number;
  x: number;
  y: number;
}

export interface ChordMarker {
  id?: string;
  instrument?: string;
  chordName: string;
  startTime: number;
  duration: number;
  x: number;
  y: number;
}
