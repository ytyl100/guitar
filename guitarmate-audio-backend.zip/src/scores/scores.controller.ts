import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import { ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { ScoresService } from './scores.service';

@ApiTags('Scores')
@Controller('api/scores')
export class ScoresController {
  constructor(private readonly scoresService: ScoresService) {}

  @Get()
  @ApiOperation({ summary: '获取全部曲目列表（包含草稿 draft 与已发布 published）' })
  async findAll() {
    return this.scoresService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: '获取单首曲目详情（包含分轨及所有小节数据）' })
  @ApiParam({ name: 'id', description: '曲目 Score ID' })
  async findOne(@Param('id') id: string) {
    return this.scoresService.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: '创建新乐谱曲目 (草稿)' })
  async create(
    @Body()
    body: {
      title: string;
      artist?: string;
      bpm?: number;
      timeSignature?: string;
      originalAudio: string;
      coverUrl?: string;
      status?: string;
    },
  ) {
    return this.scoresService.create(body);
  }

  @Post(':id/tracks')
  @ApiOperation({ summary: '为指定曲目添加分轨 (Track)' })
  @ApiParam({ name: 'id', description: '曲目 Score ID' })
  async addTrack(
    @Param('id') id: string,
    @Body()
    body: {
      instrument: string;
      audioUrl: string;
      jsonUrl?: string;
    },
  ) {
    return this.scoresService.addTrack(id, body);
  }

  @Patch(':id/status')
  @ApiOperation({ summary: '更新曲目发布状态 (draft / published)' })
  @ApiParam({ name: 'id', description: '曲目 Score ID' })
  async updateStatus(
    @Param('id') id: string,
    @Body() body: { status: 'draft' | 'published' },
  ) {
    return this.scoresService.updateStatus(id, body.status);
  }
}
