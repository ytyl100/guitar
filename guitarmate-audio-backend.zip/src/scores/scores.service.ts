import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ScoresService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll() {
    return this.prisma.score.findMany({
      include: {
        tracks: true,
        _count: {
          select: {
            measures: true,
          },
        },
      },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async findOne(id: string) {
    const score = await this.prisma.score.findUnique({
      where: { id },
      include: {
        tracks: true,
        measures: {
          orderBy: { index: 'asc' },
          include: {
            trackData: true,
            barres: true,
            chords: true,
          },
        },
      },
    });

    if (!score) {
      throw new NotFoundException(`Score with ID '${id}' not found`);
    }

    return {
      ...score,
      measures: score.measures.map((m) => ({
        ...m,
        trackData: m.trackData.map((t) => ({
          ...t,
          notes: t.notes ? JSON.parse(t.notes) : [],
        })),
      })),
    };
  }

  async create(data: {
    title: string;
    artist?: string;
    bpm?: number;
    timeSignature?: string;
    originalAudio: string;
    coverUrl?: string;
    status?: string;
  }) {
    return this.prisma.score.create({
      data: {
        title: data.title,
        artist: data.artist,
        bpm: data.bpm,
        timeSignature: data.timeSignature || '4/4',
        originalAudio: data.originalAudio,
        coverUrl: data.coverUrl,
        status: data.status || 'draft',
      },
    });
  }

  async addTrack(
    scoreId: string,
    data: {
      instrument: string;
      audioUrl: string;
      jsonUrl?: string;
    },
  ) {
    return this.prisma.track.create({
      data: {
        scoreId,
        instrument: data.instrument,
        audioUrl: data.audioUrl,
        jsonUrl: data.jsonUrl,
      },
    });
  }

  async updateStatus(id: string, status: 'draft' | 'published') {
    return this.prisma.score.update({
      where: { id },
      data: { status },
    });
  }
}
