import { Injectable, Logger } from '@nestjs/common';
import OSS from 'ali-oss';
import { createReadStream, existsSync, mkdirSync, copyFileSync } from 'fs';
import { basename, join } from 'path';

@Injectable()
export class OssService {
  private readonly logger = new Logger(OssService.name);
  private client: OSS | null = null;
  private readonly isConfigured: boolean;

  constructor() {
    const region = process.env.OSS_REGION || 'oss-cn-hangzhou';
    const accessKeyId = process.env.OSS_ACCESS_KEY_ID;
    const accessKeySecret = process.env.OSS_ACCESS_KEY_SECRET;
    const bucket = process.env.OSS_BUCKET || 'guitar-practice';

    if (accessKeyId && accessKeySecret && accessKeyId.trim().length > 3) {
      try {
        this.client = new OSS({
          region,
          accessKeyId,
          accessKeySecret,
          bucket,
        });
        this.isConfigured = true;
        this.logger.log(`Aliyun OSS initialized for bucket: ${bucket} in ${region}`);
      } catch (err: any) {
        this.logger.warn(`Failed to initialize Aliyun OSS client: ${err.message}. Falling back to local storage.`);
        this.isConfigured = false;
      }
    } else {
      this.isConfigured = false;
      this.logger.log('OSS credentials not configured in environment. Using local dev storage fallback.');
    }
  }

  async upload(localPath: string, remoteDir: string): Promise<string> {
    const filename = basename(localPath);
    const objectKey = `${remoteDir}/${filename}`;

    if (this.isConfigured && this.client) {
      try {
        this.logger.log(`Uploading to Aliyun OSS: ${objectKey}`);
        await this.client.put(objectKey, createReadStream(localPath));
        const bucket = process.env.OSS_BUCKET || 'guitar-practice';
        const region = process.env.OSS_REGION || 'oss-cn-hangzhou';
        const cdnUrl = `https://${bucket}.${region}.aliyuncs.com/${objectKey}`;
        this.logger.log(`Uploaded to OSS: ${cdnUrl}`);
        return cdnUrl;
      } catch (err: any) {
        this.logger.error(`OSS upload failed: ${err.message}. Saving to local fallback.`);
      }
    }

    // 本地开发 / 回退方案: 保存至 ./uploads 目录
    const localTargetDir = join(process.cwd(), 'uploads', remoteDir);
    if (!existsSync(localTargetDir)) {
      mkdirSync(localTargetDir, { recursive: true });
    }
    const targetFile = join(localTargetDir, filename);
    if (existsSync(localPath)) {
      copyFileSync(localPath, targetFile);
    }

    const host = process.env.APP_URL || 'http://localhost:3000';
    const fallbackUrl = `${host}/uploads/${remoteDir}/${filename}`;
    this.logger.log(`Local dev fallback upload URL: ${fallbackUrl}`);
    return fallbackUrl;
  }
}
