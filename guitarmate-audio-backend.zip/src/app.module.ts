import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { PrismaModule } from './prisma/prisma.module';
import { AudioModule } from './audio/audio.module';
import { OssModule } from './oss/oss.module';
import { MeasuresModule } from './measures/measures.module';
import { PublishedModule } from './published/published.module';
import { ScoresModule } from './scores/scores.module';

@Module({
  imports: [
    PrismaModule,
    AudioModule,
    OssModule,
    MeasuresModule,
    PublishedModule,
    ScoresModule,
  ],
  controllers: [AppController],
})
export class AppModule {}
